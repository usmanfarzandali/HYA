{
    'name': 'Automobile Website',
    'summary': 'Automobile Website',
    'version': '1.5',
    'description': """Automobile Catalog Website""",
    'author': 'Dynexcel',
    'category': 'Website',
    'website': "",
    'depends': ['base', 'website_sale', 'sale', 'website'],
    'data': [
        'views/template.xml',
        'views/product.xml',
        'data/product_action_view.xml'
    ],
    'installable': True,
    'auto_install': False,
}
