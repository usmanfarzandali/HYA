from addons.http_routing.models.ir_http import slug
from odoo import http, tools, _
from odoo.http import request
from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo.addons.website.controllers.main import Website
from odoo.addons.website.controllers.main import QueryURL


class Website(Website):
    @http.route('/', type='http', auth="public", website=True)
    def index(self, **kw):
        public_category = request.env['product.public.category'].sudo()
        categories = public_category.search([('parent_id', '=', False)])
        values = {
            'categories': categories,
        }
        return request.render("automobile_website.automobile_home_page", values)


class WebsiteAutomobile(http.Controller):

    @http.route(['/shop', '/shop/<model("product.public.category"):category>'], type='http', auth="public",
                website=True)
    def shop_page(self, category=False, search='', search_frame='', parent_category=0, **post):
        public_category = request.env['product.public.category'].sudo()
        if search_frame:
            categories = public_category.search(
                [('name', 'ilike', search_frame)])
            values = {
                'categories': categories
            }
        elif search and not parent_category:
            categories = public_category.search(
                [('name', 'ilike', search), ('parent_id', '=', False)])
            values = {
                'categories': categories
            }
        elif parent_category and search:
            categories = public_category.search(
                [('name', 'ilike', search), ('parent_id', '=', int(parent_category))])
            parent_category = public_category.search([('id', '=', int(parent_category))])
            values = {
                'categories': categories,
                'parent_category': parent_category
            }
        elif category and not search:
            if category.display_mode == 'row':
                values = {'category': category,
                          'row_categories': category.row_categ_lines}
                return request.render("automobile_website.automobile_row_categ_page", values)
            if category.child_id:
                categories = category.child_id
                values = {
                    'categories': categories,
                    'parent_category': category
                }
            elif category.display_mode == 'img_mapping':
                return request.redirect("/category/%s" % slug(category))
            else:
                return request.redirect("/shop/category/%s" % slug(category))
        else:
            categories = public_category.search([('is_car', '=', True)])
            values = {
                'categories': categories
            }
        return request.render("automobile_website.automobile_shop_page", values)

    @http.route(['/category/<model("product.public.category"):category>'], type='http', auth="public",
                website=True)
    def product_page(self, category=False, **post):
        products = request.env['product.template'].sudo().search([('public_categ_ids', '=', category.id)])
        values = {
            'category': category,
            'products': products
        }
        request.session['category'] = category.id
        return request.render("automobile_website.product_details", values)

    @http.route(['/create_new_image/<model("product.public.category"):category>'], type='http', auth="public",
                website=True)
    def create_image(self, category=False, **post):
        if category:
            products = request.env['product.template'].sudo().search([('public_categ_ids', '=', category.id)])
            values = {
                'category': category,
                'products': products
            }
            categ_image = request.env['category.image.html'].sudo().search([('category_id', '=', category.id)])
            if categ_image:
                values['image_id'] = categ_image
        return request.render("automobile_website.automobile_create_image_page", values)

    @http.route(['/create_product_image'], type='json', auth="public", website=True)
    def create_category_image(self, category_id=0, image_html=False, **kw):
        if category_id and image_html and kw.get('product_list'):
            category_image_html_obj = request.env['category.image.html'].sudo()
            category_image_html_id = category_image_html_obj.search([('category_id', '=', int(category_id))])
            if category_image_html_id:
                category_image_html_id.sudo().write({
                    'html_data': image_html
                })
            else:
                category_image_html_id = request.env['category.image.html'].sudo().create({
                    'category_id': int(category_id),
                    'html_data': image_html
                })
            for each in kw.get('product_list'):
                product = request.env['product.image.create'].sudo().search([('product_id', '=', each),
                                                                             ('category_image_id', '=',
                                                                              category_image_html_id.id)])
                if not product:
                    request.env['product.image.create'].sudo().create({
                        'product_id': each,
                        'category_image_id': category_image_html_id.id
                    })

            return True

    @http.route(['/update/cart/new'], type='json', auth="public", website=True)
    def add_product_cart(self, product_id=0, qty=1, **kw):
        print("\n\n\nhello----------",product_id,qty)
        if product_id:
            request.website.sale_get_order(force_create=1)._cart_update(
                product_id=int(product_id),
                add_qty=int(qty),
                set_qty=0,
            )
        return True

    @http.route(['/shop/category/product/<model("product.template"):product>'], type='http', auth="public",
                website=True)
    def product(self, product, **kwargs):
        category = request.env['product.public.category'].sudo().search([('id', '=', request.session.get('category'))])
        values = {
            'product': product,
            'category': category,
        }
        return request.render("automobile_website.automobile_product_page", values)

    @http.route(['/get_grade_list'], type='json', auth="public", website=True)
    def get_grade_list(self, id=0, grade_id=0, **kw):
        if id:
            grade_list = []
            product_list = []
            year_list = []
            engine_list = []
            category = request.env['product.public.category'].sudo().search([('id', '=', int(id))])
            products = request.env['product.template'].sudo().search([])
            for product in products:
                for categ in product.public_categ_ids:
                    if category.name in categ.display_name:
                        product_list.append({
                            'value': product.id,
                            'name': product.name
                        })
                        if product.model:
                            grade_list.append(product.model)
                        if product.model_year:
                            year_list.append(product.model_year)
                        if product.chases_no:
                            engine_list.append(product.chases_no)
            engine_list = set(engine_list)
            engine_list = list(engine_list)
            grade_list = set(grade_list)
            grade_list = list(grade_list)
            year_list = set(year_list)
            year_list = list(year_list)

            return {'grade_list': grade_list, 'product_list': product_list, 'year_list': year_list,
                    'engine_list': engine_list}
        if grade_id:
            product_list = []
            category = request.env['product.public.category'].sudo().search([('id', '=', int(grade_id))])
            products = request.env['product.template'].sudo().search([])
            for product in products:
                for categ in product.public_categ_ids:
                    if category.name in categ.display_name:
                        product_list.append({
                            'value': product.id,
                            'name': product.name
                        })

            return {'product_list': product_list}

    @http.route(['/search'], type='http', auth="public", website=True)
    def saerch_page(self, **post):
        product_template = request.env['product.template'].sudo()
        domain = []
        if post.get('part_number'):
            products = request.env['product.template'].sudo().search(
                [('display_code', 'ilike', post.get('part_number'))])
            value = {
                'products': products
            }
            return request.render('automobile_website.automobile_search_page', value)

        if post.get('car_selection'):
            category = request.env['product.public.category'].sudo().search(
                [('id', '=', int(post.get('car_selection')))])
            products = request.env['product.template'].sudo().search([])
            product_list = []
            for product in products:
                for categ in product.public_categ_ids:
                    if category.name in categ.display_name:
                        product_list.append(product.id)
            domain.append(('id', 'in', product_list))
        if post.get('grade_selection'):
            domain.append(('model', 'ilike', str(post.get('grade_selection'))))
        if post.get('year_selection'):
            domain.append(('model_year', 'ilike', str(post.get('year_selection'))))
        if post.get('engine_selection'):
            domain.append(('chases_no', '=', post.get('engine_selection')))
        if post.get('product_selection'):
            domain.append(('id', '=', int(post.get('product_selection'))))
        products = product_template.search(domain)
        value = {
            'products': products
        }
        return request.render('automobile_website.automobile_search_page', value)

    @http.route(['/reset_image'], type='json', auth="public", website=True)
    def reset_image(self, id=0,**kw):
        if id:
            image_id = request.env['category.image.html'].sudo().search([('category_id','=',int(id))])
            if image_id:
                for each in image_id:
                    each.unlink()
        return True
