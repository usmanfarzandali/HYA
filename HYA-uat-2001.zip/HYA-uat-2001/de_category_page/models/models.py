# -*- coding: utf-8 -*-

from odoo import models, fields, api

class PublicCategory(models.Model):
    _inherit = 'public.category'
    
    style = fields.Selection([
        ('normal', 'Default'),
        ('title', 'Title'),
        ('chart', 'Chart'),
    ], default="normal" string="Layout Style")
    vin = fields.Char(string="VIN")
    vin = fields.Char(string="VIN")
    vin = fields.Char(string="VIN")

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100