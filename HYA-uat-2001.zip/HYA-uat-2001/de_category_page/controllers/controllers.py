# -*- coding: utf-8 -*-
from odoo import http

# class DeCategoryPage(http.Controller):
#     @http.route('/de_category_page/de_category_page/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/de_category_page/de_category_page/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('de_category_page.listing', {
#             'root': '/de_category_page/de_category_page',
#             'objects': http.request.env['de_category_page.de_category_page'].search([]),
#         })

#     @http.route('/de_category_page/de_category_page/objects/<model("de_category_page.de_category_page"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('de_category_page.object', {
#             'object': obj
#         })