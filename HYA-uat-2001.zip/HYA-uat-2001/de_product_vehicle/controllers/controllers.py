# -*- coding: utf-8 -*-
from odoo import http

# class DeProductVehicle(http.Controller):
#     @http.route('/de_product_vehicle/de_product_vehicle/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/de_product_vehicle/de_product_vehicle/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('de_product_vehicle.listing', {
#             'root': '/de_product_vehicle/de_product_vehicle',
#             'objects': http.request.env['de_product_vehicle.de_product_vehicle'].search([]),
#         })

#     @http.route('/de_product_vehicle/de_product_vehicle/objects/<model("de_product_vehicle.de_product_vehicle"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('de_product_vehicle.object', {
#             'object': obj
#         })