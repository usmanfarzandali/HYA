# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ProductTemplate1(models.Model):
    _inherit = "product.template"
    
    vin = fields.Char(string='VIN', help='Vehicle Identification Number')
    chasis_no = fields.Char(string='Chasis No.', help='Chasis Number')
    
    # class de_product_vehicle(models.Model):
#     _name = 'de_product_vehicle.de_product_vehicle'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100